public class ClassNameHere
{
    public static void main(String[] args) 
    {
        
    }
}
