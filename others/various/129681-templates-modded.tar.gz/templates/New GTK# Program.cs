// created on 5/16/2006 at 10:48 AM
using System;
using Gtk;
using GtkSharp;

namespace 
{
	public class New GTK# Program : Window
	{
		public New GTK# Program () : base ("MyWindow")
		{
		}
	}
}
